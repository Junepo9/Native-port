#include "gles_renderer.h"

#include <cmath>
#include <cstdio>
#include <cstring>

#include "controls.h"
#include "cstick.h"
#include "display.h"
#include "hid.h"
#include "scene.h"
#include "settings.h"

namespace {

struct Vertex3D {
    float x, y, z;
    float nx, ny, nz;
    float r, g, b, a;
};

struct Vertex2D {
    float x, y;
    float u, v;
    float r, g, b, a;
};

static void unpackColor(uint32_t c, float& r, float& g, float& b, float& a) {
    r = static_cast<float>((c >> 16) & 0xFF) / 255.0f;
    g = static_cast<float>((c >> 8) & 0xFF) / 255.0f;
    b = static_cast<float>(c & 0xFF) / 255.0f;
    a = static_cast<float>((c >> 24) & 0xFF) / 255.0f;
}

static GLuint compileShader(GLenum type, const char* source) {
    GLuint s = glCreateShader(type);
    if (!s) return 0;
    glShaderSource(s, 1, &source, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        LOGE("Shader compilation failed: %s\n", log);
        glDeleteShader(s);
        return 0;
    }
    return s;
}

static GLuint linkProgram(GLuint vs, GLuint fs) {
    GLuint p = glCreateProgram();
    if (!p) return 0;
    glAttachShader(p, vs);
    glAttachShader(p, fs);
    glLinkProgram(p);
    GLint ok = 0;
    glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetProgramInfoLog(p, sizeof(log), nullptr, log);
        LOGE("Program linking failed: %s\n", log);
        glDeleteProgram(p);
        return 0;
    }
    return p;
}

// 24 vertices for 6 faces of a cube with proper flat normals
static const Vertex3D kCubeFaceVertices[24] = {
    // Front face (Z = +1)
    {-1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    { 1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    { 1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    {-1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, 1.0f, 1.0f, 1.0f},

    // Back face (Z = -1)
    { 1.0f, -1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    {-1.0f, -1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    {-1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    { 1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 1.0f, 1.0f, 1.0f, 1.0f},

    // Top face (Y = +1)
    {-1.0f,  1.0f,  1.0f,  0.0f,  1.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    { 1.0f,  1.0f,  1.0f,  0.0f,  1.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    { 1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    {-1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},

    // Bottom face (Y = -1)
    {-1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    { 1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    { 1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    {-1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},

    // Right face (X = +1)
    { 1.0f, -1.0f,  1.0f,  1.0f,  0.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    { 1.0f, -1.0f, -1.0f,  1.0f,  0.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    { 1.0f,  1.0f, -1.0f,  1.0f,  0.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    { 1.0f,  1.0f,  1.0f,  1.0f,  0.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},

    // Left face (X = -1)
    {-1.0f, -1.0f, -1.0f, -1.0f,  0.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    {-1.0f, -1.0f,  1.0f, -1.0f,  0.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    {-1.0f,  1.0f,  1.0f, -1.0f,  0.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
    {-1.0f,  1.0f, -1.0f, -1.0f,  0.0f,  0.0f, 1.0f, 1.0f, 1.0f, 1.0f},
};

static const uint16_t kCubeIndices[36] = {
     0,  1,  2,   0,  2,  3,  // front
     4,  5,  6,   4,  6,  7,  // back
     8,  9, 10,   8, 10, 11,  // top
    12, 13, 14,  12, 14, 15,  // bottom
    16, 17, 18,  16, 18, 19,  // right
    20, 21, 22,  20, 22, 23,  // left
};

}  // namespace

// ===========================================================================
// ScreenFbo Implementation
// ===========================================================================

bool ScreenFbo::create(int w, int h, bool linearFilter) {
    destroy();
    width = w;
    height = h;

    glGenFramebuffers(1, &fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);

    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    GLint filter = linearFilter ? GL_LINEAR : GL_NEAREST;
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, texture, 0);

    glGenRenderbuffers(1, &rbo);
    glBindRenderbuffer(GL_RENDERBUFFER, rbo);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, w, h);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rbo);

    GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    if (status != GL_FRAMEBUFFER_COMPLETE) {
        LOGE("Framebuffer creation incomplete: 0x%x\n", status);
        destroy();
        return false;
    }
    return true;
}

void ScreenFbo::setFilter(bool linear) {
    if (texture) {
        glBindTexture(GL_TEXTURE_2D, texture);
        GLint filter = linear ? GL_LINEAR : GL_NEAREST;
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter);
        glBindTexture(GL_TEXTURE_2D, 0);
    }
}

void ScreenFbo::destroy() {
    if (rbo) {
        glDeleteRenderbuffers(1, &rbo);
        rbo = 0;
    }
    if (texture) {
        glDeleteTextures(1, &texture);
        texture = 0;
    }
    if (fbo) {
        glDeleteFramebuffers(1, &fbo);
        fbo = 0;
    }
    width = 0;
    height = 0;
}

// ===========================================================================
// GlesRenderer Implementation
// ===========================================================================

GlesRenderer::GlesRenderer() {}

GlesRenderer::~GlesRenderer() {
    shutdown();
}

bool GlesRenderer::init(SDL_Window* win) {
    window = win;

    // Request OpenGL ES 3.0 context
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
    SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 0);

    glContext = SDL_GL_CreateContext(window);
    if (!glContext) {
        // Fallback to GLES 2.0 if 3.0 is not available on host
        LOGI("Falling back to OpenGL ES 2.0 context...\n");
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
        glContext = SDL_GL_CreateContext(window);
        if (!glContext) {
            LOGE("SDL_GL_CreateContext failed: %s\n", SDL_GetError());
            return false;
        }
    }

    SDL_GL_MakeCurrent(window, glContext);

    const char* glVendor = reinterpret_cast<const char*>(glGetString(GL_VENDOR));
    const char* glRenderer = reinterpret_cast<const char*>(glGetString(GL_RENDERER));
    const char* glVersion = reinterpret_cast<const char*>(glGetString(GL_VERSION));
    const char* glslVersion = reinterpret_cast<const char*>(glGetString(GL_SHADING_LANGUAGE_VERSION));

    LOGI("OpenGL ES Initialized:\n  Vendor: %s\n  Renderer: %s\n  Version: %s\n  GLSL: %s\n",
         glVendor ? glVendor : "Unknown",
         glRenderer ? glRenderer : "Unknown",
         glVersion ? glVersion : "Unknown",
         glslVersion ? glslVersion : "Unknown");

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    if (!initShaders()) return false;
    if (!initGeometry()) return false;

    // Create default native screens (400x240 and 320x240)
    if (!topFbo.create(TOP_W, TOP_H, false)) return false;
    if (!botFbo.create(BOT_W, BOT_H, false)) return false;

    current2DProj = Mat4::ortho(0.0f, 1280.0f, 720.0f, 0.0f);

    return true;
}

bool GlesRenderer::initShaders() {
    // -----------------------------------------------------------------------
    // 3D Shader (Diffuse directional lighting + Ambient + ModelViewProjection)
    // -----------------------------------------------------------------------
    const char* vs3D =
        "#version 100\n"
        "precision highp float;\n"
        "attribute vec3 a_position;\n"
        "attribute vec3 a_normal;\n"
        "attribute vec4 a_color;\n"
        "uniform mat4 u_mvp;\n"
        "uniform mat4 u_model;\n"
        "varying vec3 v_normal;\n"
        "varying vec4 v_color;\n"
        "void main() {\n"
        "    v_normal = mat3(u_model[0].xyz, u_model[1].xyz, u_model[2].xyz) * a_normal;\n"
        "    v_color = a_color;\n"
        "    gl_Position = u_mvp * vec4(a_position, 1.0);\n"
        "}\n";

    const char* fs3D =
        "#version 100\n"
        "precision highp float;\n"
        "varying vec3 v_normal;\n"
        "varying vec4 v_color;\n"
        "uniform vec3 u_lightDir;\n"
        "uniform vec3 u_ambient;\n"
        "uniform int u_useLighting;\n"
        "void main() {\n"
        "    if (u_useLighting != 0) {\n"
        "        vec3 n = normalize(v_normal);\n"
        "        float diff = max(dot(n, u_lightDir), 0.0);\n"
        "        vec3 lighting = u_ambient + vec3(0.82) * diff;\n"
        "        gl_FragColor = vec4(v_color.rgb * lighting, v_color.a);\n"
        "    } else {\n"
        "        gl_FragColor = v_color;\n"
        "    }\n"
        "}\n";

    GLuint vs3 = compileShader(GL_VERTEX_SHADER, vs3D);
    GLuint fs3 = compileShader(GL_FRAGMENT_SHADER, fs3D);
    if (!vs3 || !fs3) return false;
    prog3D = linkProgram(vs3, fs3);
    glDeleteShader(vs3);
    glDeleteShader(fs3);
    if (!prog3D) return false;

    u3D_mvp = glGetUniformLocation(prog3D, "u_mvp");
    u3D_model = glGetUniformLocation(prog3D, "u_model");
    u3D_lightDir = glGetUniformLocation(prog3D, "u_lightDir");
    u3D_ambient = glGetUniformLocation(prog3D, "u_ambient");
    u3D_useLighting = glGetUniformLocation(prog3D, "u_useLighting");

    // -----------------------------------------------------------------------
    // 2D Shader (Ortho projection, textured quads / flat colors with alpha)
    // -----------------------------------------------------------------------
    const char* vs2D =
        "#version 100\n"
        "precision highp float;\n"
        "attribute vec2 a_position;\n"
        "attribute vec2 a_texCoord;\n"
        "attribute vec4 a_color;\n"
        "uniform mat4 u_proj;\n"
        "varying vec2 v_texCoord;\n"
        "varying vec4 v_color;\n"
        "void main() {\n"
        "    v_texCoord = a_texCoord;\n"
        "    v_color = a_color;\n"
        "    gl_Position = u_proj * vec4(a_position, 0.0, 1.0);\n"
        "}\n";

    const char* fs2D =
        "#version 100\n"
        "precision highp float;\n"
        "varying vec2 v_texCoord;\n"
        "varying vec4 v_color;\n"
        "uniform sampler2D u_texture;\n"
        "uniform int u_hasTexture;\n"
        "void main() {\n"
        "    if (u_hasTexture != 0) {\n"
        "        gl_FragColor = texture2D(u_texture, v_texCoord) * v_color;\n"
        "    } else {\n"
        "        gl_FragColor = v_color;\n"
        "    }\n"
        "}\n";

    GLuint vs2 = compileShader(GL_VERTEX_SHADER, vs2D);
    GLuint fs2 = compileShader(GL_FRAGMENT_SHADER, fs2D);
    if (!vs2 || !fs2) return false;
    prog2D = linkProgram(vs2, fs2);
    glDeleteShader(vs2);
    glDeleteShader(fs2);
    if (!prog2D) return false;

    u2D_proj = glGetUniformLocation(prog2D, "u_proj");
    u2D_texture = glGetUniformLocation(prog2D, "u_texture");
    u2D_hasTexture = glGetUniformLocation(prog2D, "u_hasTexture");

    return true;
}

bool GlesRenderer::initGeometry() {
    // Cube VBO & IBO
    glGenBuffers(1, &vboCube);
    glBindBuffer(GL_ARRAY_BUFFER, vboCube);
    glBufferData(GL_ARRAY_BUFFER, sizeof(kCubeFaceVertices), kCubeFaceVertices, GL_STATIC_DRAW);

    glGenBuffers(1, &iboCube);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, iboCube);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(kCubeIndices), kCubeIndices, GL_STATIC_DRAW);

    // Dynamic stream buffer for 2D/3D immediate draws
    glGenBuffers(1, &vboDynamic);
    glBindBuffer(GL_ARRAY_BUFFER, vboDynamic);
    glBufferData(GL_ARRAY_BUFFER, 4096 * sizeof(Vertex2D), nullptr, GL_DYNAMIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    return true;
}

void GlesRenderer::shutdown() {
    topFbo.destroy();
    botFbo.destroy();

    if (vboCube) { glDeleteBuffers(1, &vboCube); vboCube = 0; }
    if (iboCube) { glDeleteBuffers(1, &iboCube); iboCube = 0; }
    if (vboDynamic) { glDeleteBuffers(1, &vboDynamic); vboDynamic = 0; }

    if (prog3D) { glDeleteProgram(prog3D); prog3D = 0; }
    if (prog2D) { glDeleteProgram(prog2D); prog2D = 0; }

    if (glContext) {
        SDL_GL_DeleteContext(glContext);
        glContext = nullptr;
    }
}

bool GlesRenderer::resizeScreens(int topW, int topH, int botW, int botH, bool linearFilter) {
    if (!topFbo.create(topW, topH, linearFilter)) return false;
    if (!botFbo.create(botW, botH, linearFilter)) return false;
    return true;
}

void GlesRenderer::setFilterMode(bool linear) {
    topFbo.setFilter(linear);
    botFbo.setFilter(linear);
}

void GlesRenderer::beginFrame(int winW, int winH) {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, winW, winH);
    glClearColor(24.0f / 255.0f, 24.0f / 255.0f, 28.0f / 255.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
}

void GlesRenderer::endFrame() {
    SDL_GL_SwapWindow(window);
}

void GlesRenderer::beginTopScreen(float r, float g, float b) {
    glBindFramebuffer(GL_FRAMEBUFFER, topFbo.fbo);
    glViewport(0, 0, topFbo.width, topFbo.height);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glClearColor(r, g, b, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void GlesRenderer::endTopScreen() {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void GlesRenderer::beginBottomScreen(float r, float g, float b) {
    glBindFramebuffer(GL_FRAMEBUFFER, botFbo.fbo);
    glViewport(0, 0, botFbo.width, botFbo.height);
    glDisable(GL_DEPTH_TEST);
    glClearColor(r, g, b, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
}

void GlesRenderer::endBottomScreen() {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

// ===========================================================================
// 3D Rendering Functions
// ===========================================================================

void GlesRenderer::draw3DCube(float x, float y, float z, float scale, float yaw, float pitch,
                             uint32_t color, const Mat4& view, const Mat4& proj) {
    glEnable(GL_DEPTH_TEST);
    glUseProgram(prog3D);

    // Model matrix
    Mat4 mScale = Mat4::scale(scale, scale, scale);
    Mat4 mRotX = Mat4::rotateX(pitch);
    Mat4 mRotY = Mat4::rotateY(yaw);
    Mat4 mTrans = Mat4::translate(x, y, z);
    Mat4 model = mTrans * mRotY * mRotX * mScale;

    Mat4 mvp = proj * view * model;

    glUniformMatrix4fv(u3D_mvp, 1, GL_FALSE, mvp.m);
    glUniformMatrix4fv(u3D_model, 1, GL_FALSE, model.m);

    // Directional light matching scene.h kLight (-0.40f, 0.75f, -0.53f)
    Vec3 light = normalizeV(v3(-0.40f, 0.75f, -0.53f));
    glUniform3f(u3D_lightDir, light.x, light.y, light.z);
    glUniform3f(u3D_ambient, 0.18f, 0.18f, 0.18f);
    glUniform1i(u3D_useLighting, 1);

    // Apply color to vertices
    float cr, cg, cb, ca;
    unpackColor(color, cr, cg, cb, ca);

    Vertex3D coloredVerts[24];
    for (int i = 0; i < 24; i++) {
        coloredVerts[i] = kCubeFaceVertices[i];
        coloredVerts[i].r = cr;
        coloredVerts[i].g = cg;
        coloredVerts[i].b = cb;
        coloredVerts[i].a = ca;
    }

    glBindBuffer(GL_ARRAY_BUFFER, vboCube);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(coloredVerts), coloredVerts);

    GLint locPos = glGetAttribLocation(prog3D, "a_position");
    GLint locNorm = glGetAttribLocation(prog3D, "a_normal");
    GLint locCol = glGetAttribLocation(prog3D, "a_color");

    glEnableVertexAttribArray(locPos);
    glVertexAttribPointer(locPos, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex3D),
                          reinterpret_cast<void*>(offsetof(Vertex3D, x)));

    glEnableVertexAttribArray(locNorm);
    glVertexAttribPointer(locNorm, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex3D),
                          reinterpret_cast<void*>(offsetof(Vertex3D, nx)));

    glEnableVertexAttribArray(locCol);
    glVertexAttribPointer(locCol, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex3D),
                          reinterpret_cast<void*>(offsetof(Vertex3D, r)));

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, iboCube);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_SHORT, nullptr);

    glDisableVertexAttribArray(locPos);
    glDisableVertexAttribArray(locNorm);
    glDisableVertexAttribArray(locCol);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}

void GlesRenderer::draw3DLine(float x0, float y0, float z0, float x1, float y1, float z1,
                             uint32_t color, const Mat4& view, const Mat4& proj) {
    glEnable(GL_DEPTH_TEST);
    glUseProgram(prog3D);

    Mat4 model = Mat4::identity();
    Mat4 mvp = proj * view * model;

    glUniformMatrix4fv(u3D_mvp, 1, GL_FALSE, mvp.m);
    glUniformMatrix4fv(u3D_model, 1, GL_FALSE, model.m);
    glUniform1i(u3D_useLighting, 0);

    float cr, cg, cb, ca;
    unpackColor(color, cr, cg, cb, ca);

    Vertex3D lineVerts[2] = {
        {x0, y0, z0, 0.0f, 1.0f, 0.0f, cr, cg, cb, ca},
        {x1, y1, z1, 0.0f, 1.0f, 0.0f, cr, cg, cb, ca}
    };

    glBindBuffer(GL_ARRAY_BUFFER, vboDynamic);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(lineVerts), lineVerts);

    GLint locPos = glGetAttribLocation(prog3D, "a_position");
    GLint locCol = glGetAttribLocation(prog3D, "a_color");

    glEnableVertexAttribArray(locPos);
    glVertexAttribPointer(locPos, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex3D),
                          reinterpret_cast<void*>(offsetof(Vertex3D, x)));

    glEnableVertexAttribArray(locCol);
    glVertexAttribPointer(locCol, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex3D),
                          reinterpret_cast<void*>(offsetof(Vertex3D, r)));

    glDrawArrays(GL_LINES, 0, 2);

    glDisableVertexAttribArray(locPos);
    glDisableVertexAttribArray(locCol);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void GlesRenderer::draw3DGrid(float y, int count, const Mat4& view, const Mat4& proj) {
    std::vector<Vertex3D> gridVerts;
    gridVerts.reserve(static_cast<size_t>(count * 2 + 1) * 4);

    for (int i = -count; i <= count; i++) {
        uint32_t col = (i == 0) ? rgb(70, 110, 70) : rgb(40, 62, 40);
        float cr, cg, cb, ca;
        unpackColor(col, cr, cg, cb, ca);

        float fi = static_cast<float>(i);
        float fn = static_cast<float>(count);

        // Line along X
        gridVerts.push_back({-fn, y, fi, 0.0f, 1.0f, 0.0f, cr, cg, cb, ca});
        gridVerts.push_back({ fn, y, fi, 0.0f, 1.0f, 0.0f, cr, cg, cb, ca});

        // Line along Z
        gridVerts.push_back({fi, y, -fn, 0.0f, 1.0f, 0.0f, cr, cg, cb, ca});
        gridVerts.push_back({fi, y,  fn, 0.0f, 1.0f, 0.0f, cr, cg, cb, ca});
    }

    glEnable(GL_DEPTH_TEST);
    glUseProgram(prog3D);

    Mat4 model = Mat4::identity();
    Mat4 mvp = proj * view * model;

    glUniformMatrix4fv(u3D_mvp, 1, GL_FALSE, mvp.m);
    glUniformMatrix4fv(u3D_model, 1, GL_FALSE, model.m);
    glUniform1i(u3D_useLighting, 0);

    glBindBuffer(GL_ARRAY_BUFFER, vboDynamic);
    glBufferData(GL_ARRAY_BUFFER, gridVerts.size() * sizeof(Vertex3D), gridVerts.data(), GL_DYNAMIC_DRAW);

    GLint locPos = glGetAttribLocation(prog3D, "a_position");
    GLint locCol = glGetAttribLocation(prog3D, "a_color");

    glEnableVertexAttribArray(locPos);
    glVertexAttribPointer(locPos, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex3D),
                          reinterpret_cast<void*>(offsetof(Vertex3D, x)));

    glEnableVertexAttribArray(locCol);
    glVertexAttribPointer(locCol, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex3D),
                          reinterpret_cast<void*>(offsetof(Vertex3D, r)));

    glDrawArrays(GL_LINES, 0, static_cast<GLsizei>(gridVerts.size()));

    glDisableVertexAttribArray(locPos);
    glDisableVertexAttribArray(locCol);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

// ===========================================================================
// 2D Rendering Functions
// ===========================================================================

void GlesRenderer::set2DProjection(float left, float right, float bottom, float top) {
    current2DProj = Mat4::ortho(left, right, bottom, top);
}

void GlesRenderer::draw2DRect(float x, float y, float w, float h, uint32_t color) {
    float r, g, b, a;
    unpackColor(color, r, g, b, a);

    Vertex2D v[6] = {
        {x,     y,     0.0f, 0.0f, r, g, b, a},
        {x + w, y,     1.0f, 0.0f, r, g, b, a},
        {x + w, y + h, 1.0f, 1.0f, r, g, b, a},

        {x,     y,     0.0f, 0.0f, r, g, b, a},
        {x + w, y + h, 1.0f, 1.0f, r, g, b, a},
        {x,     y + h, 0.0f, 1.0f, r, g, b, a},
    };

    glDisable(GL_DEPTH_TEST);
    glUseProgram(prog2D);
    glUniformMatrix4fv(u2D_proj, 1, GL_FALSE, current2DProj.m);
    glUniform1i(u2D_hasTexture, 0);

    glBindBuffer(GL_ARRAY_BUFFER, vboDynamic);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(v), v);

    GLint locPos = glGetAttribLocation(prog2D, "a_position");
    GLint locUV  = glGetAttribLocation(prog2D, "a_texCoord");
    GLint locCol = glGetAttribLocation(prog2D, "a_color");

    glEnableVertexAttribArray(locPos);
    glVertexAttribPointer(locPos, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, x)));

    glEnableVertexAttribArray(locUV);
    glVertexAttribPointer(locUV, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, u)));

    glEnableVertexAttribArray(locCol);
    glVertexAttribPointer(locCol, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, r)));

    glDrawArrays(GL_TRIANGLES, 0, 6);

    glDisableVertexAttribArray(locPos);
    glDisableVertexAttribArray(locUV);
    glDisableVertexAttribArray(locCol);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void GlesRenderer::draw2DTexturedQuad(GLuint texture, float x, float y, float w, float h,
                                     uint32_t tint, bool flipY) {
    float r, g, b, a;
    unpackColor(tint, r, g, b, a);

    float v0 = flipY ? 1.0f : 0.0f;
    float v1 = flipY ? 0.0f : 1.0f;

    Vertex2D v[6] = {
        {x,     y,     0.0f, v0, r, g, b, a},
        {x + w, y,     1.0f, v0, r, g, b, a},
        {x + w, y + h, 1.0f, v1, r, g, b, a},

        {x,     y,     0.0f, v0, r, g, b, a},
        {x + w, y + h, 1.0f, v1, r, g, b, a},
        {x,     y + h, 0.0f, v1, r, g, b, a},
    };

    glDisable(GL_DEPTH_TEST);
    glUseProgram(prog2D);
    glUniformMatrix4fv(u2D_proj, 1, GL_FALSE, current2DProj.m);
    glUniform1i(u2D_hasTexture, 1);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture);
    glUniform1i(u2D_texture, 0);

    glBindBuffer(GL_ARRAY_BUFFER, vboDynamic);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(v), v);

    GLint locPos = glGetAttribLocation(prog2D, "a_position");
    GLint locUV  = glGetAttribLocation(prog2D, "a_texCoord");
    GLint locCol = glGetAttribLocation(prog2D, "a_color");

    glEnableVertexAttribArray(locPos);
    glVertexAttribPointer(locPos, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, x)));

    glEnableVertexAttribArray(locUV);
    glVertexAttribPointer(locUV, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, u)));

    glEnableVertexAttribArray(locCol);
    glVertexAttribPointer(locCol, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, r)));

    glDrawArrays(GL_TRIANGLES, 0, 6);

    glDisableVertexAttribArray(locPos);
    glDisableVertexAttribArray(locUV);
    glDisableVertexAttribArray(locCol);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindTexture(GL_TEXTURE_2D, 0);
}

void GlesRenderer::draw2DCircle(float cx, float cy, float radius, uint32_t color, int segments) {
    float r, g, b, a;
    unpackColor(color, r, g, b, a);

    std::vector<Vertex2D> verts;
    verts.reserve(static_cast<size_t>(segments) * 3);

    for (int i = 0; i < segments; i++) {
        float a0 = (static_cast<float>(i) / segments) * 2.0f * static_cast<float>(M_PI);
        float a1 = (static_cast<float>(i + 1) / segments) * 2.0f * static_cast<float>(M_PI);

        verts.push_back({cx, cy, 0.0f, 0.0f, r, g, b, a});
        verts.push_back({cx + std::cos(a0) * radius, cy + std::sin(a0) * radius, 0.0f, 0.0f, r, g, b, a});
        verts.push_back({cx + std::cos(a1) * radius, cy + std::sin(a1) * radius, 0.0f, 0.0f, r, g, b, a});
    }

    glDisable(GL_DEPTH_TEST);
    glUseProgram(prog2D);
    glUniformMatrix4fv(u2D_proj, 1, GL_FALSE, current2DProj.m);
    glUniform1i(u2D_hasTexture, 0);

    glBindBuffer(GL_ARRAY_BUFFER, vboDynamic);
    glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(Vertex2D), verts.data(), GL_DYNAMIC_DRAW);

    GLint locPos = glGetAttribLocation(prog2D, "a_position");
    GLint locUV  = glGetAttribLocation(prog2D, "a_texCoord");
    GLint locCol = glGetAttribLocation(prog2D, "a_color");

    glEnableVertexAttribArray(locPos);
    glVertexAttribPointer(locPos, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, x)));

    glEnableVertexAttribArray(locUV);
    glVertexAttribPointer(locUV, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, u)));

    glEnableVertexAttribArray(locCol);
    glVertexAttribPointer(locCol, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, r)));

    glDrawArrays(GL_TRIANGLES, 0, static_cast<GLsizei>(verts.size()));

    glDisableVertexAttribArray(locPos);
    glDisableVertexAttribArray(locUV);
    glDisableVertexAttribArray(locCol);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void GlesRenderer::draw2DRoundRect(float x, float y, float w, float h, float radius, uint32_t color) {
    if (radius > w * 0.5f) radius = w * 0.5f;
    if (radius > h * 0.5f) radius = h * 0.5f;

    // Center and edge rects
    draw2DRect(x + radius, y, w - 2.0f * radius, h, color);
    draw2DRect(x, y + radius, radius, h - 2.0f * radius, color);
    draw2DRect(x + w - radius, y + radius, radius, h - 2.0f * radius, color);

    // 4 rounded corners
    draw2DCircle(x + radius, y + radius, radius, color, 16);
    draw2DCircle(x + w - radius, y + radius, radius, color, 16);
    draw2DCircle(x + radius, y + h - radius, radius, color, 16);
    draw2DCircle(x + w - radius, y + h - radius, radius, color, 16);
}

void GlesRenderer::draw2DLine(float x0, float y0, float x1, float y1, uint32_t color) {
    float r, g, b, a;
    unpackColor(color, r, g, b, a);

    Vertex2D v[2] = {
        {x0, y0, 0.0f, 0.0f, r, g, b, a},
        {x1, y1, 0.0f, 0.0f, r, g, b, a}
    };

    glDisable(GL_DEPTH_TEST);
    glUseProgram(prog2D);
    glUniformMatrix4fv(u2D_proj, 1, GL_FALSE, current2DProj.m);
    glUniform1i(u2D_hasTexture, 0);

    glBindBuffer(GL_ARRAY_BUFFER, vboDynamic);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(v), v);

    GLint locPos = glGetAttribLocation(prog2D, "a_position");
    GLint locUV  = glGetAttribLocation(prog2D, "a_texCoord");
    GLint locCol = glGetAttribLocation(prog2D, "a_color");

    glEnableVertexAttribArray(locPos);
    glVertexAttribPointer(locPos, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, x)));

    glEnableVertexAttribArray(locUV);
    glVertexAttribPointer(locUV, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, u)));

    glEnableVertexAttribArray(locCol);
    glVertexAttribPointer(locCol, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex2D),
                          reinterpret_cast<void*>(offsetof(Vertex2D, r)));

    glDrawArrays(GL_LINES, 0, 2);

    glDisableVertexAttribArray(locPos);
    glDisableVertexAttribArray(locUV);
    glDisableVertexAttribArray(locCol);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void GlesRenderer::draw2DArrow(float cx, float cy, int dir, uint32_t color) {
    for (int i = 0; i < 14; i++) {
        switch (dir) {
            case 0: draw2DLine(cx - i, cy - 10 + i, cx + i, cy - 10 + i, color); break;
            case 1: draw2DLine(cx - i, cy + 10 - i, cx + i, cy + 10 - i, color); break;
            case 2: draw2DLine(cx - 10 + i, cy - i, cx - 10 + i, cy + i, color); break;
            case 3: draw2DLine(cx + 10 - i, cy - i, cx + 10 - i, cy + i, color); break;
        }
    }
}

void GlesRenderer::draw2DText(const char* text, float cx, float cy, int scale, uint32_t color) {
    int n = static_cast<int>(std::strlen(text));
    float width = static_cast<float>(n * 6 * scale - scale);
    float startX = cx - width * 0.5f;
    float startY = cy - (7.0f * scale) * 0.5f;

    for (int i = 0; i < n; i++) {
        const uint8_t* rows = findGlyph(text[i]);
        if (rows) {
            for (int row = 0; row < 7; row++) {
                for (int col = 0; col < 5; col++) {
                    if (rows[row] & (1 << (4 - col))) {
                        draw2DRect(startX + col * scale, startY + row * scale,
                                   static_cast<float>(scale), static_cast<float>(scale), color);
                    }
                }
            }
        }
        startX += 6.0f * scale;
    }
}

// ===========================================================================
// Presentation and Controls
// ===========================================================================

void GlesRenderer::presentDualScreens(const Layout& L) {
    set2DProjection(0.0f, static_cast<float>(L.vw), static_cast<float>(L.vh), 0.0f);

    // Dark bezels behind screens
    draw2DRoundRect(static_cast<float>(L.top.x - 8), static_cast<float>(L.top.y - 8),
                    static_cast<float>(L.top.w + 16), static_cast<float>(L.top.h + 16), 10.0f, rgb(10, 10, 12));
    draw2DRoundRect(static_cast<float>(L.bot.x - 8), static_cast<float>(L.bot.y - 8),
                    static_cast<float>(L.bot.w + 16), static_cast<float>(L.bot.h + 16), 10.0f, rgb(10, 10, 12));

    // Top screen FBO (flipY = true to convert OpenGL FBO orientation)
    draw2DTexturedQuad(topFbo.texture, static_cast<float>(L.top.x), static_cast<float>(L.top.y),
                       static_cast<float>(L.top.w), static_cast<float>(L.top.h), 0xFFFFFFFF, true);

    // Bottom screen FBO
    draw2DTexturedQuad(botFbo.texture, static_cast<float>(L.bot.x), static_cast<float>(L.bot.y),
                       static_cast<float>(L.bot.w), static_cast<float>(L.bot.h), 0xFFFFFFFF, true);
}

void GlesRenderer::renderControls(const Layout& L, const HidState& hid, float cstickX, float cstickY) {
    set2DProjection(0.0f, static_cast<float>(L.vw), static_cast<float>(L.vh), 0.0f);

    // Circle Pad
    draw2DCircle(static_cast<float>(L.cpX), static_cast<float>(L.cpY), static_cast<float>(L.cpR), rgb(62, 62, 74));
    draw2DCircle(static_cast<float>(L.cpX), static_cast<float>(L.cpY), static_cast<float>(L.cpR - 6), rgb(26, 26, 32));

    bool steering = (hid.circleX != 0.0f || hid.circleY != 0.0f);
    float knobX = static_cast<float>(L.cpX) + hid.circleX * static_cast<float>(L.cpR - 38);
    float knobY = static_cast<float>(L.cpY) - hid.circleY * static_cast<float>(L.cpR - 38);
    uint32_t knobCol = steering ? rgb(196, 196, 214) : rgb(150, 150, 168);
    draw2DCircle(knobX, knobY, 44.0f, knobCol);

    // D-Pad
    struct Arm {
        uint32_t bit;
        int dx, dy, dir;
    };
    const Arm arms[] = {
        {BTN_DUP, 0, -1, 0}, {BTN_DDOWN, 0, 1, 1},
        {BTN_DLEFT, -1, 0, 2}, {BTN_DRIGHT, 1, 0, 3}
    };
    const int half = DPAD_ARM / 2;
    draw2DRect(static_cast<float>(L.dpadX - half), static_cast<float>(L.dpadY - half),
               static_cast<float>(DPAD_ARM), static_cast<float>(DPAD_ARM), rgb(80, 80, 92));
    draw2DRect(static_cast<float>(L.dpadX - half + 4), static_cast<float>(L.dpadY - half + 4),
               static_cast<float>(DPAD_ARM - 8), static_cast<float>(DPAD_ARM - 8), rgb(36, 36, 44));

    for (const auto& a : arms) {
        bool pressed = (hid.held & a.bit) != 0;
        float rx = static_cast<float>(L.dpadX - half + a.dx * DPAD_ARM);
        float ry = static_cast<float>(L.dpadY - half + a.dy * DPAD_ARM);
        draw2DRoundRect(rx, ry, static_cast<float>(DPAD_ARM), static_cast<float>(DPAD_ARM), 12.0f, rgb(80, 80, 92));
        uint32_t innerCol = pressed ? rgb(235, 235, 245) : rgb(36, 36, 44);
        draw2DRoundRect(rx + 4.0f, ry + 4.0f, static_cast<float>(DPAD_ARM - 8), static_cast<float>(DPAD_ARM - 8), 9.0f, innerCol);
        uint32_t arrowCol = pressed ? rgb(20, 20, 30) : rgb(215, 215, 230);
        draw2DArrow(rx + DPAD_ARM * 0.5f, ry + DPAD_ARM * 0.5f, a.dir, arrowCol);
    }

    // Other Buttons (A, B, X, Y, L, R, ZL, ZR, Start, Select)
    for (const auto& c : L.ctrls) {
        bool pressed = (hid.held & c.bit) != 0;
        float cx = static_cast<float>(c.rect.x + c.rect.w / 2);
        float cy = static_cast<float>(c.rect.y + c.rect.h / 2);

        if (c.round) {
            float rad = static_cast<float>(c.rect.w / 2);
            draw2DCircle(cx, cy, rad, rgb(80, 80, 92));
            uint32_t inCol = pressed ? rgb(235, 235, 245) : rgb(36, 36, 44);
            draw2DCircle(cx, cy, rad - 4.0f, inCol);
        } else {
            draw2DRoundRect(static_cast<float>(c.rect.x), static_cast<float>(c.rect.y),
                            static_cast<float>(c.rect.w), static_cast<float>(c.rect.h), 14.0f, rgb(80, 80, 92));
            uint32_t inCol = pressed ? rgb(235, 235, 245) : rgb(36, 36, 44);
            draw2DRoundRect(static_cast<float>(c.rect.x + 4), static_cast<float>(c.rect.y + 4),
                            static_cast<float>(c.rect.w - 8), static_cast<float>(c.rect.h - 8), 11.0f, inCol);
        }

        uint32_t textCol = pressed ? rgb(20, 20, 30) : rgb(215, 215, 230);
        if (c.label) {
            int scale = c.round ? 5 : (std::strlen(c.label) > 2 ? 3 : 4);
            draw2DText(c.label, cx, cy, scale, textCol);
        }
    }

    // C-Stick
    int csCx = cstickCx();
    int csCy = cstickCy();
    draw2DCircle(static_cast<float>(csCx), static_cast<float>(csCy), static_cast<float>(CSTICK_R + 12), rgb(30, 30, 38));
    draw2DCircle(static_cast<float>(csCx), static_cast<float>(csCy), static_cast<float>(CSTICK_R + 5), rgb(52, 52, 62));
    draw2DCircle(static_cast<float>(csCx), static_cast<float>(csCy), static_cast<float>(CSTICK_R), rgb(22, 22, 28));

    float csNx = static_cast<float>(csCx) + cstickX * static_cast<float>(CSTICK_R - 12);
    float csNy = static_cast<float>(csCy) + cstickY * static_cast<float>(CSTICK_R - 12);
    draw2DCircle(csNx, csNy, 20.0f, rgb(210, 210, 230));
}

void GlesRenderer::renderSettings(const Settings& st) {
    set2DProjection(0.0f, static_cast<float>(gL.vw), static_cast<float>(gL.vh), 0.0f);

    // Settings SET button
    SDL_Rect b = settingsButtonRect();
    uint32_t btnCol = st.open ? rgb(88, 88, 112) : rgb(44, 44, 56);
    draw2DRoundRect(static_cast<float>(b.x), static_cast<float>(b.y),
                    static_cast<float>(b.w), static_cast<float>(b.h), 8.0f, btnCol);
    draw2DText("SET", static_cast<float>(b.x + b.w / 2), static_cast<float>(b.y + b.h / 2), 3, rgb(215, 215, 230));

    if (!st.open) return;

    // Dim backdrop
    draw2DRect(0.0f, 0.0f, static_cast<float>(gL.vw), static_cast<float>(gL.vh), 0xAA000000);

    // Settings panel card
    float px = static_cast<float>(settingsPanelX());
    float py = static_cast<float>(settingsPanelY());
    float pw = static_cast<float>(settingsPanelW());
    float ph = static_cast<float>(settingsPanelH());

    draw2DRoundRect(px, py, pw, ph, 12.0f, rgb(26, 26, 34));
    draw2DRect(px, py, pw, 3.0f, rgb(88, 88, 112));

    draw2DText("GRAPHICS", px + pw * 0.5f, py + 46.0f, 4, rgb(235, 235, 245));

    const char* labels[4] = {"RESOLUTION", "FPS LIMIT", "FILTER", "BACK"};
    const char* values[4] = {kResNames[st.resIdx], kFpsNames[st.fpsIdx],
                             kFilterNames[st.filterIdx], ""};

    for (int i = 0; i < 4; i++) {
        SDL_Rect row = settingsRowRect(i);
        draw2DRoundRect(static_cast<float>(row.x), static_cast<float>(row.y),
                        static_cast<float>(row.w), static_cast<float>(row.h), 8.0f, rgb(38, 38, 48));

        if (i == 3) {
            draw2DText(labels[i], static_cast<float>(row.x + row.w / 2),
                       static_cast<float>(row.y + row.h / 2), 3, rgb(210, 210, 228));
        } else {
            draw2DText(labels[i], static_cast<float>(row.x + row.w / 4),
                       static_cast<float>(row.y + row.h / 2), 3, rgb(210, 210, 228));
            draw2DText(values[i], static_cast<float>(row.x + (row.w * 3) / 4),
                       static_cast<float>(row.y + row.h / 2), 3, rgb(120, 220, 150));
        }
    }
}
