#pragma once

#include <cstdio>
#include <cstdlib>

#ifdef __ANDROID__
    #include <GLES3/gl3.h>
    #include <GLES3/gl3ext.h>
    #include <android/log.h>
    #define LOG_TAG "NativePort"
    #define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
    #define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#else
    #define LOGI(...) std::printf(__VA_ARGS__)
    #define LOGE(...) std::fprintf(stderr, __VA_ARGS__)

    #if defined(__has_include)
        #if __has_include(<GLES3/gl3.h>)
            #include <GLES3/gl3.h>
            #include <GLES3/gl3ext.h>
        #elif __has_include(<GLES2/gl2.h>)
            #include <GLES2/gl2.h>
            #include <GLES2/gl2ext.h>
        #else
            #ifndef SDL_USE_BUILTIN_OPENGL_DEFINITIONS
            #define SDL_USE_BUILTIN_OPENGL_DEFINITIONS 1
            #endif
            #if __has_include(<SDL_opengles2.h>)
                #include <SDL_opengles2.h>
            #elif __has_include(<SDL2/SDL_opengles2.h>)
                #include <SDL2/SDL_opengles2.h>
            #endif
        #endif
    #else
        #include <GLES3/gl3.h>
    #endif
#endif
