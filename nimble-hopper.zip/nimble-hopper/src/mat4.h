#pragma once

#include <cmath>
#include <cstring>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Column-major 4x4 matrix matching OpenGL ES shader layout.
struct Mat4 {
    // Array layout:
    // m[0]  m[4]  m[8]   m[12]
    // m[1]  m[5]  m[9]   m[13]
    // m[2]  m[6]  m[10]  m[14]
    // m[3]  m[7]  m[11]  m[15]
    float m[16] = {0.0f};

    static inline Mat4 identity() {
        Mat4 r;
        r.m[0] = 1.0f;
        r.m[5] = 1.0f;
        r.m[10] = 1.0f;
        r.m[15] = 1.0f;
        return r;
    }

    static inline Mat4 translate(float x, float y, float z) {
        Mat4 r = identity();
        r.m[12] = x;
        r.m[13] = y;
        r.m[14] = z;
        return r;
    }

    static inline Mat4 scale(float sx, float sy, float sz) {
        Mat4 r;
        r.m[0] = sx;
        r.m[5] = sy;
        r.m[10] = sz;
        r.m[15] = 1.0f;
        return r;
    }

    static inline Mat4 rotateX(float angleRad) {
        Mat4 r = identity();
        float c = std::cos(angleRad);
        float s = std::sin(angleRad);
        r.m[5] = c;
        r.m[6] = s;
        r.m[9] = -s;
        r.m[10] = c;
        return r;
    }

    static inline Mat4 rotateY(float angleRad) {
        Mat4 r = identity();
        float c = std::cos(angleRad);
        float s = std::sin(angleRad);
        r.m[0] = c;
        r.m[2] = -s;
        r.m[8] = s;
        r.m[10] = c;
        return r;
    }

    static inline Mat4 rotateZ(float angleRad) {
        Mat4 r = identity();
        float c = std::cos(angleRad);
        float s = std::sin(angleRad);
        r.m[0] = c;
        r.m[1] = s;
        r.m[4] = -s;
        r.m[5] = c;
        return r;
    }

    static inline Mat4 multiply(const Mat4& a, const Mat4& b) {
        Mat4 r;
        for (int col = 0; col < 4; col++) {
            for (int row = 0; row < 4; row++) {
                float sum = 0.0f;
                for (int k = 0; k < 4; k++) {
                    sum += a.m[k * 4 + row] * b.m[col * 4 + k];
                }
                r.m[col * 4 + row] = sum;
            }
        }
        return r;
    }

    inline Mat4 operator*(const Mat4& b) const {
        return multiply(*this, b);
    }

    static inline Mat4 perspective(float fovYRad, float aspect, float nearZ, float farZ) {
        Mat4 r;
        float f = 1.0f / std::tan(fovYRad * 0.5f);
        r.m[0]  = f / aspect;
        r.m[5]  = f;
        r.m[10] = (farZ + nearZ) / (nearZ - farZ);
        r.m[11] = -1.0f;
        r.m[14] = (2.0f * farZ * nearZ) / (nearZ - farZ);
        return r;
    }

    static inline Mat4 ortho(float left, float right, float bottom, float top, float nearZ = -1.0f, float farZ = 1.0f) {
        Mat4 r;
        float rl = right - left;
        float tb = top - bottom;
        float fn = farZ - nearZ;
        r.m[0]  = 2.0f / rl;
        r.m[5]  = 2.0f / tb;
        r.m[10] = -2.0f / fn;
        r.m[12] = -(right + left) / rl;
        r.m[13] = -(top + bottom) / tb;
        r.m[14] = -(farZ + nearZ) / fn;
        r.m[15] = 1.0f;
        return r;
    }

    static inline Mat4 lookAt(float eyeX, float eyeY, float eyeZ,
                              float targetX, float targetY, float targetZ,
                              float upX, float upY, float upZ) {
        // Forward = target - eye
        float fx = targetX - eyeX;
        float fy = targetY - eyeY;
        float fz = targetZ - eyeZ;
        float flen = std::sqrt(fx * fx + fy * fy + fz * fz);
        if (flen > 1e-6f) { fx /= flen; fy /= flen; fz /= flen; }

        // Right = cross(forward, up)
        float rx = fy * upZ - fz * upY;
        float ry = fz * upX - fx * upZ;
        float rz = fx * upY - fy * upX;
        float rlen = std::sqrt(rx * rx + ry * ry + rz * rz);
        if (rlen > 1e-6f) { rx /= rlen; ry /= rlen; rz /= rlen; }

        // Up = cross(right, forward)
        float ux = ry * fz - rz * fy;
        float uy = rz * fx - rx * fz;
        float uz = rx * fy - ry * fx;

        Mat4 r = identity();
        r.m[0] = rx;
        r.m[4] = ry;
        r.m[8] = rz;
        r.m[12] = -(rx * eyeX + ry * eyeY + rz * eyeZ);

        r.m[1] = ux;
        r.m[5] = uy;
        r.m[9] = uz;
        r.m[13] = -(ux * eyeX + uy * eyeY + uz * eyeZ);

        r.m[2] = -fx;
        r.m[6] = -fy;
        r.m[10] = -fz;
        r.m[14] = (fx * eyeX + fy * eyeY + fz * eyeZ);

        return r;
    }
};
