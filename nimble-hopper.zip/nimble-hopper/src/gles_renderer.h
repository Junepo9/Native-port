#pragma once

#include <SDL.h>
#include <cstdint>
#include <string>
#include <vector>

#include "gl_loader.h"
#include "mat4.h"

// Forward declarations
struct Layout;
struct HidState;
struct Settings;
struct Camera;

struct ScreenFbo {
    GLuint fbo = 0;
    GLuint texture = 0;
    GLuint rbo = 0;
    int width = 0;
    int height = 0;

    bool create(int w, int h, bool linearFilter = false);
    void setFilter(bool linear);
    void destroy();
};

class GlesRenderer {
public:
    GlesRenderer();
    ~GlesRenderer();

    // Lifecycle
    bool init(SDL_Window* window);
    void shutdown();

    // Screen buffer resizing and filtering
    bool resizeScreens(int topW, int topH, int botW, int botH, bool linearFilter);
    void setFilterMode(bool linear);

    // Frame management
    void beginFrame(int winW, int winH);
    void endFrame();

    // Off-screen dual-screen passes
    void beginTopScreen(float r = 0.0f, float g = 0.0f, float b = 0.0f);
    void endTopScreen();

    void beginBottomScreen(float r = 0.08f, float g = 0.08f, float b = 0.10f);
    void endBottomScreen();

    // 3D Rendering (hardware accelerated via OpenGL ES)
    void draw3DCube(float x, float y, float z, float scale, float yaw, float pitch,
                    uint32_t color, const Mat4& view, const Mat4& proj);
    void draw3DGrid(float y, int count, const Mat4& view, const Mat4& proj);
    void draw3DLine(float x0, float y0, float z0, float x1, float y1, float z1,
                    uint32_t color, const Mat4& view, const Mat4& proj);

    // 2D Rendering
    void set2DProjection(float left, float right, float bottom, float top);
    void draw2DRect(float x, float y, float w, float h, uint32_t color);
    void draw2DTexturedQuad(GLuint texture, float x, float y, float w, float h,
                            uint32_t tint = 0xFFFFFFFF, bool flipY = false);
    void draw2DCircle(float cx, float cy, float radius, uint32_t color, int segments = 28);
    void draw2DRoundRect(float x, float y, float w, float h, float radius, uint32_t color);
    void draw2DLine(float x0, float y0, float x1, float y1, uint32_t color);
    void draw2DArrow(float cx, float cy, int dir, uint32_t color);
    void draw2DText(const char* text, float cx, float cy, int scale, uint32_t color);

    // Presentation and UI
    void presentDualScreens(const Layout& L);
    void renderControls(const Layout& L, const HidState& hid, float cstickX, float cstickY);
    void renderSettings(const Settings& st);

    // Accessors
    SDL_GLContext getContext() const { return glContext; }
    const ScreenFbo& getTopScreen() const { return topFbo; }
    const ScreenFbo& getBottomScreen() const { return botFbo; }

private:
    SDL_Window* window = nullptr;
    SDL_GLContext glContext = nullptr;

    ScreenFbo topFbo;
    ScreenFbo botFbo;

    // Shader programs
    GLuint prog3D = 0;
    GLint u3D_mvp = -1;
    GLint u3D_model = -1;
    GLint u3D_lightDir = -1;
    GLint u3D_ambient = -1;
    GLint u3D_useLighting = -1;

    GLuint prog2D = 0;
    GLint u2D_proj = -1;
    GLint u2D_texture = -1;
    GLint u2D_hasTexture = -1;

    // Mesh buffers
    GLuint vaoCube = 0;
    GLuint vboCube = 0;
    GLuint iboCube = 0;

    GLuint vaoDynamic = 0;
    GLuint vboDynamic = 0;

    Mat4 current2DProj;

    bool initShaders();
    bool initGeometry();
};
