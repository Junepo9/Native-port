#include <SDL.h>

#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>

#include "controls.h"
#include "cstick.h"
#include "display.h"
#include "gles_renderer.h"
#include "hid.h"
#include "mat4.h"
#include "scene.h"
#include "settings.h"

enum class State { Waiting, Valid, Invalid };

static const size_t HEADER_SIZE = 512;

static bool loadHeader(const std::string& path, unsigned char* buf, size_t& len) {
    FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    len = std::fread(buf, 1, HEADER_SIZE, f);
    std::fclose(f);
    return len > 0;
}

static bool looksLike3dsGame(const unsigned char* buf, size_t len) {
    if (len < 0x104) return false;
    return std::memcmp(buf + 0x100, "NCSD", 4) == 0 ||
           std::memcmp(buf + 0x100, "NCCH", 4) == 0;
}

static void topClearColor(State s, float& r, float& g, float& b) {
    switch (s) {
        case State::Valid:
            r = 0.05f; g = 0.30f; b = 0.12f;
            break;
        case State::Invalid:
            r = 0.35f; g = 0.05f; b = 0.05f;
            break;
        default:
            r = 0.06f; g = 0.06f; b = 0.24f;
            break;
    }
}

// Rebuild both offscreen GLES screen buffers at the chosen resolution.
static bool updateGlesScreens(GlesRenderer& gles, const Settings& st,
                             int& outTw, int& outTh, int& outBw, int& outBh, float& outScale) {
    outScale = static_cast<float>(kResHeights[st.resIdx]) / 240.0f;
    outTw = static_cast<int>(400.0f * outScale + 0.5f);
    outTh = static_cast<int>(240.0f * outScale + 0.5f);
    outBw = static_cast<int>(320.0f * outScale + 0.5f);
    outBh = static_cast<int>(240.0f * outScale + 0.5f);

    bool linear = (st.filterIdx == 1);
    return gles.resizeScreens(outTw, outTh, outBw, outBh, linear);
}

int main(int, char**) {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER) != 0) {
        std::fprintf(stderr, "SDL_Init failed: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Window* window =
        SDL_CreateWindow("OoT3D Port", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1024,
                         576, SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
    if (!window) {
        std::fprintf(stderr, "SDL_CreateWindow failed: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    GlesRenderer gles;
    if (!gles.init(window)) {
        std::fprintf(stderr, "GlesRenderer init failed!\n");
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    applyLayout(window);

    Settings st;
    int tw = 400, th = 240, bw = 320, bh = 240;
    float scale = 1.0f;
    if (!updateGlesScreens(gles, st, tw, th, bw, bh, scale)) {
        std::fprintf(stderr, "Screen FBO create failed!\n");
        gles.shutdown();
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    int appliedRes = st.resIdx;
    int appliedFilter = st.filterIdx;

    std::string headerPath = "header.bin";
#ifdef __ANDROID__
    const char* base = SDL_AndroidGetInternalStoragePath();
    if (base) headerPath = std::string(base) + "/header.bin";
#endif

    unsigned char header[HEADER_SIZE];
    std::memset(header, 0, sizeof(header));
    size_t headerLen = 0;
    State state = State::Waiting;
    long frame = 0;

    Input input;
    HidState hid;
    SDL_FingerID stickFinger = NO_FINGER;
    SDL_FingerID uiFinger = NO_FINGER;
    bool btnHeld = false;

    Camera cam;

    float boxX = 0.0f;
    float boxY = 0.0f;
    int colorIdx = 0;
    const uint32_t palette[4] = {
        rgb(255, 200, 0),
        rgb(0, 200, 255),
        rgb(255, 80, 120),
        rgb(120, 255, 120)
    };
    boxX = tw * 0.75f;
    boxY = th * 0.82f;

    const Uint64 freq = SDL_GetPerformanceFrequency();
    Uint64 last = SDL_GetPerformanceCounter();
    double acc = 0.0;
    const double dt = 1.0 / 60.0;

    bool running = true;
    while (running) {
        const Uint64 frameStart = SDL_GetPerformanceCounter();

        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) running = false;
            if (e.type == SDL_WINDOWEVENT && (e.window.event == SDL_WINDOWEVENT_SIZE_CHANGED ||
                                              e.window.event == SDL_WINDOWEVENT_RESIZED)) {
                applyLayout(window);
            }
            handleEvent(input, window, e);
        }

        if (state == State::Waiting && frame % 30 == 0) {
            if (loadHeader(headerPath, header, headerLen)) {
                state = looksLike3dsGame(header, headerLen) ? State::Valid : State::Invalid;
            }
        }
        frame++;

        // --- Settings: the SET button ------------------------------------
        bool onBtn = false;
        for (const auto& t : input.touches) {
            if (pointInRect(static_cast<int>(t.x), static_cast<int>(t.y), settingsButtonRect())) {
                onBtn = true;
            }
        }
        if (onBtn && !btnHeld) st.open = !st.open;
        btnHeld = onBtn;

        // --- Settings: taps on the rows ----------------------------------
        if (st.open) {
            int hitRow = -1;
            SDL_FingerID hitId = NO_FINGER;
            for (const auto& t : input.touches) {
                for (int i = 0; i < 4; i++) {
                    if (pointInRect(static_cast<int>(t.x), static_cast<int>(t.y), settingsRowRect(i))) {
                        hitRow = i;
                        hitId = t.id;
                        break;
                    }
                }
                if (hitRow >= 0) break;
            }

            if (hitRow >= 0 && hitId != uiFinger) {
                uiFinger = hitId;
                if (hitRow == 0) {
                    st.resIdx = (st.resIdx + 1) % 5;
                } else if (hitRow == 1) {
                    st.fpsIdx = (st.fpsIdx + 1) % 3;
                } else if (hitRow == 2) {
                    st.filterIdx = (st.filterIdx + 1) % 2;
                } else {
                    st.open = false;
                }
            }
            if (hitRow < 0) uiFinger = NO_FINGER;
        }

        // Apply a resolution or filter change now that input is settled.
        if (st.resIdx != appliedRes || st.filterIdx != appliedFilter) {
            if (updateGlesScreens(gles, st, tw, th, bw, bh, scale)) {
                appliedRes = st.resIdx;
                appliedFilter = st.filterIdx;
            }
        }

        // The C-stick steers the camera, unless the menu is open.
        StickAxis stick;
        if (!st.open) stick = pollCStick(input, stickFinger);

        // --- Fixed 60 Hz updates -----------------------------------------
        Uint64 now = SDL_GetPerformanceCounter();
        acc += static_cast<double>(now - last) / static_cast<double>(freq);
        last = now;
        if (acc > 0.25) acc = 0.25;
        while (acc >= dt) {
            if (!st.open) {
                updateHid(hid, input);

                if (stick.active) {
                    cam.yaw -= stick.x * 0.045f;
                    cam.pitch += stick.y * 0.035f;
                }
                if (cam.pitch < -0.15f) cam.pitch = -0.15f;
                if (cam.pitch > 1.25f) cam.pitch = 1.25f;

                float mx = hid.circleX;
                float my = -hid.circleY;
                if (hid.held & BTN_DLEFT) mx -= 1.0f;
                if (hid.held & BTN_DRIGHT) mx += 1.0f;
                if (hid.held & BTN_DUP) my -= 1.0f;
                if (hid.held & BTN_DDOWN) my += 1.0f;
                if (mx > 1.0f) mx = 1.0f;
                if (mx < -1.0f) mx = -1.0f;
                if (my > 1.0f) my = 1.0f;
                if (my < -1.0f) my = -1.0f;

                boxX += mx * 2.5f * scale;
                boxY += my * 2.5f * scale;
                if (boxX < 0) boxX = 0;
                if (boxY < 0) boxY = 0;
                if (boxX > tw - 24 * scale) boxX = tw - 24 * scale;
                if (boxY > th - 24 * scale) boxY = th - 24 * scale;

                if (hid.down & BTN_A) colorIdx = (colorIdx + 1) % 4;
            }
            acc -= dt;
        }

        float time = static_cast<float>(SDL_GetTicks()) * 0.001f;

        // ===================================================================
        // Render 1: Top 3DS Screen Pass (OpenGL ES 3D Hardware Accelerated)
        // ===================================================================
        float clrR, clrG, clrB;
        topClearColor(state, clrR, clrG, clrB);
        gles.beginTopScreen(clrR, clrG, clrB);

        // Header visualizer on top edge
        if (headerLen >= 0x120) {
            gles.set2DProjection(0.0f, static_cast<float>(tw), static_cast<float>(th), 0.0f);
            float cellW = static_cast<float>(tw) / 32.0f;
            float cellH = (static_cast<float>(th) * 10.0f) / 240.0f;
            if (cellW < 1.0f) cellW = 1.0f;
            if (cellH < 1.0f) cellH = 1.0f;
            for (int i = 0; i < 32; i++) {
                int v = header[0x100 + i];
                gles.draw2DRect(static_cast<float>(i) * cellW, 0.0f, cellW - 1.0f, cellH, rgb(v, v, v));
            }
        }

        // 3D Scene setup: Camera Orbit & Perspective Matrix
        Mat4 proj = Mat4::perspective(45.0f * (static_cast<float>(M_PI) / 180.0f),
                                      static_cast<float>(tw) / static_cast<float>(th),
                                      0.1f, 100.0f);

        float eyeX = cam.dist * std::sin(cam.yaw) * std::cos(cam.pitch);
        float eyeY = cam.dist * std::sin(cam.pitch);
        float eyeZ = cam.dist * std::cos(cam.yaw) * std::cos(cam.pitch);
        Mat4 view = Mat4::lookAt(eyeX, eyeY, eyeZ, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);

        // Draw ground grid
        gles.draw3DGrid(-1.25f, 5, view, proj);

        // Center spinning cube
        gles.draw3DCube(0.0f, 0.0f, 0.0f, 0.9f, time * 0.7f, time * 0.35f,
                        rgb(90, 220, 130), view, proj);

        // Orbiting cube
        float orb = time * 0.9f;
        gles.draw3DCube(std::cos(orb) * 2.1f, 0.35f, std::sin(orb) * 2.1f, 0.35f,
                        orb * 2.0f, orb * 1.2f, rgb(230, 160, 60), view, proj);

        // Player box
        gles.set2DProjection(0.0f, static_cast<float>(tw), static_cast<float>(th), 0.0f);
        gles.draw2DRoundRect(boxX, boxY, 24.0f * scale, 24.0f * scale, 4.0f * scale, palette[colorIdx]);

        gles.endTopScreen();

        // ===================================================================
        // Render 2: Bottom 3DS Screen Pass (OpenGL ES 2D Hardware Accelerated)
        // ===================================================================
        gles.beginBottomScreen(20.0f / 255.0f, 20.0f / 255.0f, 26.0f / 255.0f);
        gles.set2DProjection(0.0f, static_cast<float>(bw), static_cast<float>(bh), 0.0f);

        // Subscreen touch grid
        float step = 20.0f * scale;
        for (float x = 0; x < bw; x += step) {
            gles.draw2DLine(x, 0.0f, x, static_cast<float>(bh), rgb(40, 40, 50));
        }
        for (float y = 0; y < bh; y += step) {
            gles.draw2DLine(0.0f, y, static_cast<float>(bw), y, rgb(40, 40, 50));
        }

        // Subscreen touch indicator
        if (hid.touching) {
            float dotX = static_cast<float>(hid.touchX * bw) / static_cast<float>(BOT_W);
            float dotY = static_cast<float>(hid.touchY * bh) / static_cast<float>(BOT_H);
            gles.draw2DCircle(dotX, dotY, 6.0f * scale, rgb(0, 220, 255));
        }

        gles.endBottomScreen();

        // ===================================================================
        // Render 3: Window Presentation & On-screen Controls (OpenGL ES)
        // ===================================================================
        int winW = 1, winH = 1;
        SDL_GL_GetDrawableSize(window, &winW, &winH);
        gles.beginFrame(winW, winH);

        // Present dual screens (bezels + top screen FBO texture + bottom screen FBO texture)
        gles.presentDualScreens(gL);

        // Render on-screen virtual controls (Circle Pad, D-pad, face buttons, shoulder buttons, C-stick)
        gles.renderControls(gL, hid, stick.active ? stick.x : 0.0f, stick.active ? stick.y : 0.0f);

        // Render settings button & panel
        gles.renderSettings(st);

        // Swap window backbuffer
        gles.endFrame();

        // --- Frame pacing -------------------------------------------------
        if (st.fpsIdx < 2) {
            double budget = (st.fpsIdx == 0) ? (1.0 / 30.0) : (1.0 / 60.0);
            double spent = static_cast<double>(SDL_GetPerformanceCounter() - frameStart) /
                           static_cast<double>(freq);
            double wait = budget - spent;
            if (wait > 0.0) SDL_Delay(static_cast<Uint32>(wait * 1000.0));
        }
    }

    for (SDL_GameController* pad : input.pads) SDL_GameControllerClose(pad);
    gles.shutdown();
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
